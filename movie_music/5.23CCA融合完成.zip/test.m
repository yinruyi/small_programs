x = round(8*rand(20,15))
y = round(8*rand(20,2))
z = ccaFuse(x,y)